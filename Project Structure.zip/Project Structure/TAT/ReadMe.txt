*Modular Functions*
  All the functions are modular, i.e., you can cut and paste them in any program you like.
  As long as the functions receive a valid file_path parameter (the file path of the document you want to
  analyse), they will run without error.

*Repeating code sections*
  At the start of each function, there is code to ensure that .docx files are successfully imported for use
  within the function (just incase you were wondering what that code does).

*Contact*
  Feel free to send me an e-mail at any time if something is unclear.
  tspvanderwalt@gmail.com

